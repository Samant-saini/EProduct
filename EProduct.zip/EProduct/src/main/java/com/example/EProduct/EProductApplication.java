package com.example.EProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(EProductApplication.class, args);
	}

}
